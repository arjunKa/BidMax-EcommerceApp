Import project into eclipse as a WAR file. Make sure Apache tomcat 10.1v is the target runtime, and all web libraries are unselected on the "WAR Import: Web libraries" page, so that they will be added in project folder automatically. This is a maven project.

All test scripts are in folder: TestScripts
Report is titled: EECS4413_Asg2_document.pdf